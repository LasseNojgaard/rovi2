# CAROS #
[![pipeline status](https://gitlab.com/caro-sdu/caros/badges/master/pipeline.svg)](https://gitlab.com/caro-sdu/caros/commits/master)

See https://gitlab.com/caro-sdu/caros/wikis/home
