\mainpage
<!-- markdown-toc start - Don't edit this section. Run M-x markdown-toc/generate-toc again -->
**Table of Contents**

- [caros_control_msgs](#caroscontrolmsgs)

<!-- markdown-toc end -->

# caros_control_msgs #
This component contains messages and services for controlling actuated entities such as grippers and serial devices.
