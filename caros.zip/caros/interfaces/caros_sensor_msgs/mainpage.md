\mainpage
<!-- markdown-toc start - Don't edit this section. Run M-x markdown-toc/generate-toc again -->
**Table of Contents**

- [caros_sensor_msgs](#carossensormsgs)

<!-- markdown-toc end -->

# caros_sensor_msgs #
This component contains ROS message types for various sensors, e.g. buttons and tactile arrays.
